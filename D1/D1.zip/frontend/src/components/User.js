import React from 'react';

class User extends React.Component {
    constructor(props) {
        super(props);
      }
  render() {
    return (
      <div>
        <h1>Hello, User Page!</h1>

      </div>
    );
  }
}

export { User };
