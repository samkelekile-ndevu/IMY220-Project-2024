import React from 'react';

class AddComment extends React.Component {
    constructor(props) {
        super(props);
      }
  render() {
    return (
      <div>
        <h1>Hello, AddComment Page!</h1>

      </div>
    );
  }
}

export { AddComment };
